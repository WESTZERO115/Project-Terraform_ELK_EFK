# 변수 temp에 10을 저장함

temp = 10

if temp > 20 :
    print("얇은 옷을 입으세요!")
else :
    print("두꺼운 옷을 입으세요!" )
