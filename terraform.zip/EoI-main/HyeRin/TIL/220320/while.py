sign = "stop"

#sign이라는 변수의 값이 문자열 stop이라면,, 무한루프
while sign == "stop" :
    sign = input("현재 신호를 입력하시오 : ")

print("OK! 진행합니다.")
