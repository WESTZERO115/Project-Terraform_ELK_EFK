#사용자로부터 두 개의 정수를 입력받아서 두 수의 합과 차를 구하는 프로그램

x = int(input("첫 번째 정수 : "))
y = int(input("두 번째 정수 : "))

sum = x + y
diff = x - y
print("두 수의 합은 : ", sum)
print("두 수의 차는 : ", diff)
