# 조건문

score = int(input("점수를 입력하세요 : "))
if score >= 60 :
    print("축하드립니다. 합격입니다.")
else :
    print("아쉽게도 불합격입니다.")

# 부울(bool) 변수 알아보기
flag = True

if flag:
    print("참입니다.")
else :
    print("거짓입니다.")
