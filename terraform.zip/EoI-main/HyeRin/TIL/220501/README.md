### 4-1강 AWS EC and SSH
https://enchanted-camp-cdc.notion.site/4-1-AWS-EC-and-SSH-5196d69ab4b04c5da3c872eabcd486fc

### 4-2강 Zsh 및 Oh-my-zsh 설치
https://enchanted-camp-cdc.notion.site/4-2-Zsh-Oh-my-zsh-5bb1e63fdbd84af1aa48d15400ec87cd

### 5-1강 AWS CLI 및 Terraform 설치
https://enchanted-camp-cdc.notion.site/5-1-AWS-CLI-Terraform-a82ef9a5f64e43d19a50c415e9a42dd8

