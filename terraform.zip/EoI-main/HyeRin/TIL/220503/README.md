### 6강 테라폼 작동원리와 CLI 실습
https://enchanted-camp-cdc.notion.site/6-CLI-fa9d59ecbd2047cc8dfdf07e12998b7f

### 7강 VPC 소개
https://enchanted-camp-cdc.notion.site/7-VPC-870a4491f55a454c9f46a80f5f46de41

### 8강 VPC와 subnet 생성하기
https://enchanted-camp-cdc.notion.site/8-VPC-subnet-4e4b6cbc2f1a4b06ba365f58dcb7e041

### 9강 IGW와 NAT 게이트웨이 생성하기
https://enchanted-camp-cdc.notion.site/9-IGW-NAT-b7f72b699d794824a463e4272fab1af5

### 10강 Route Table 구성하기
https://enchanted-camp-cdc.notion.site/10-Route-Table-25f9a0f3d76544658dc2918e586cb258

### 11강 Amazon S3 소개
https://enchanted-camp-cdc.notion.site/11-Amazon-S3-bf315c49bfd944fabcd2d262fff20b33

### 12강 Amazon S3 실습
https://enchanted-camp-cdc.notion.site/12-Amazon-S3-ddf0debc5cbb48d1b091866ba42725a4
