### 16강 Backend 활용하기
https://enchanted-camp-cdc.notion.site/16-Backend-a20120deca034f3a8591063f86e1555f

### 17강 Variables 활용하기
https://enchanted-camp-cdc.notion.site/17-Variables-528c0b61a8f44d528b3cc64f3ec991cf

### 18강 Functions 활용하기
https://enchanted-camp-cdc.notion.site/18-Functions-9488caf387384b65bc22391fe72ab568


