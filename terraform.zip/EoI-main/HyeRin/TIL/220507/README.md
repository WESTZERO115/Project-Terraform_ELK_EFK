### 18강 속성 출력
https://enchanted-camp-cdc.notion.site/18-9fcbfe98d4974897a0ec22cfdb1f42a1

### 20강 원격 상태
https://enchanted-camp-cdc.notion.site/20-19152bf0b57543aca8a2e74a2a203af0

### 22강 데이터소스
https://enchanted-camp-cdc.notion.site/22-51282d9a06974ad18869162ef0e8be07

### 24강 템플릿 공급자
https://enchanted-camp-cdc.notion.site/24-e53fedfeb183497995fbf87d724a9b5d
