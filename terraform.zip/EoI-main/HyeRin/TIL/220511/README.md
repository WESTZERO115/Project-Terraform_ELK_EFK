### 30강 VPC 
https://enchanted-camp-cdc.notion.site/30-VPC-fa1166ea2ead4257864458f33ecf514f

### 34강 VPC에서 EC2 인스턴스 시작하기
https://enchanted-camp-cdc.notion.site/34-VPC-EC2-97d2cfc8dfe04581b3a6f689c227a090

### 36강 EBS 볼륨
https://enchanted-camp-cdc.notion.site/36-EBS-d22a9563ed3d495489ab7be5be8d7fcc

### 38강 사용자 데이터
https://enchanted-camp-cdc.notion.site/38-f5bce2726de44bd9b081dc43e9b08bf2

### 40강 고정 IP와 DNS
https://enchanted-camp-cdc.notion.site/40-IP-DNS-5821af80f65d4273af1b947af1f9fb66

### 42강 RDS
https://enchanted-camp-cdc.notion.site/42-RDS-6264ea7d2a8a462e83e0402ce585f193
