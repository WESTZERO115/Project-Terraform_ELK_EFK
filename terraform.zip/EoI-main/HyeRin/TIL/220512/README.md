### 44강 IAM 
https://enchanted-camp-cdc.notion.site/44-IAM-2690bcfaf2b24029b6bba7afd716b2fe

### 48강 자동스케일링
https://enchanted-camp-cdc.notion.site/48-3eeff99c611d4ae4b85a496b1fa83664

### 50강 ELB 이론
https://enchanted-camp-cdc.notion.site/50-ELB-3c155e461d6447d090c8d53a6827d909
