### 82강 ECS과 ALB 모듈
https://enchanted-camp-cdc.notion.site/82-ECS-ALB-29d0ca503c1d4e7bab55037f18953513
