# Ansible 
:heavy_check_mark:앤서블(Ansible)을 깊이 있게 활용하기

:link: https://www.inflearn.com/course/ansible-%EC%8B%AC%ED%99%94/dashboard

### 실습환경 구성하기
https://enchanted-camp-cdc.notion.site/9d45df7719ea42c087953dc5f832f45f

### 플레이북을 동적으로 구성하기
https://enchanted-camp-cdc.notion.site/d0168be4b4984efc81bc755d72ea9889

### 플레이북을 짜임새 있게 구성하기
https://enchanted-camp-cdc.notion.site/4259ac0334834d92b9922f5ab69e5014
