### 80강 ECS 실습1
 우분투에 도커 설치 후 실행

https://enchanted-camp-cdc.notion.site/80-7f3ae58b02144b4a9dd1370bc161ea4e

### 81강 ECS 실습2
 젠킨스 설치 후 깃 레파지토리연결하여 빌드하기

https://enchanted-camp-cdc.notion.site/81-c280a56d07b242e3a21d5264abf2ec11
